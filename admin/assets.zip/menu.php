<ul class="nav-second-level nav" aria-expanded="true">
									
									<li><a href="class-7.php">Class 7th</a></li>
                                    <li><a href="class-8.php">Class 8th</a></li>
									<li><a href="class-9.php">Class 9th</a></li>
									<li><a href="class-10.php">Class 10th</a></li>
									<li><a href="class-11.php">Class +1 (old Entries)</a></li>
									<li><a href="class-11med.php">Class +1 Medical</a></li>
									<li><a href="class-11nonmed.php">Class +1 Non Medical</a></li>
										</ul>