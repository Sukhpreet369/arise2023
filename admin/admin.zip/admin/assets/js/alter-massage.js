function confirmation(){
    var result = confirm("Are you sure to delete?");
    if(result)
	{ 
	return true;
	}
	else
	{
	return false;
	}
} 